# Eulerverfahren für DGLs
euler <- function(y0,t0,fun,dt,steps){
  
  val = numeric(steps+1)  # Vektor für Funktionswerte y(t)
  val[1] = y0             # Durch AWP gegeben
  
  # Iteration
  for(i in 2:(steps+1)){
    tC <- t0+dt*(i-2)
    val[i] = val[i-1]+dt*fun(val[i-1],tC)
  }
  
  return(val)
}

# Differenzialgleichung für die Übungsaufgabe 4
exercise <- function(y,t){
  return(y^2)
}

# Analytische Lösung für die Übungsaufgabe 4
exercise_sol <- function(t){
  return((0.25-t)^(-1))
}

# Parametrierung und Aufruf

y0 <- 4         # Werte des AWP
t0 <- 0         # Werte des AWP
dt <- 1         # Schrittweite
steps <- 5      # Anzahl der Schritte

t <- t0 + (0:steps)*dt # Zeitachse
yEuler <- euler(y0,t0,exercise,dt,steps) # Werteachse

# Liniendiagramm zur Visualisierung der numerischen Lösung
plot(t,yEuler,type="l",main="Aufgabe 4")

# Exakte Werte zur Bewertung der numerischen Lösung
yExact <- exercise_sol(t)

# Absolute und relative Fehler berechnen
errAbs <- abs(yEuler - yExact)
errRel <- errAbs/yExact

# Liniendiagramm zur Visualisierung des Fehlers der numerischen Lösung
plot(t,errAbs,type="l",ylab="Absoluter Fehler",main="Aufgabe 4")
