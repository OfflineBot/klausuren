# Newton-Algorithmus für Suche nach Nullstellen
newtonRoots <- function(x,epsilon,fun,derivative){
  
  val <- fun(x)
  
  if(abs(val)<epsilon){
    cat(paste("Nullstelle bei ",x," mit Wert ",val,"\n"))
    return(x) # Abbruchbedingung
  }
  
  dfx <- derivative(x) # Analytische Ableitung
  newX = x - val/dfx # Simpsonsche Formel
  
  return(newtonRoots(newX,epsilon,fun,derivative)) # Rekursive Iteration
}

# Beispielfunktion aus Aufgabe 2 mit Nullstellen bei -2 und 5
exampleFun <- function(x){
  return(x^2-3*x-10)
}

# Ableitung der Beispielfunktion die wir analytisch berechnen müssen.
exampleDerivative <- function(x){
  return(2*x-3)
}

# Funktionsaufruf

xVal = seq(-10,10,0.5)
xVal = xVal[-24]
yVal = numeric(length(xVal))

for(i in 1:length(xVal)){
  yVal[i] <- newtonRoots(xVal[i],0.1,exampleFun,exampleDerivative)
}
