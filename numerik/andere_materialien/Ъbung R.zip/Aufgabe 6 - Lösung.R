# Trapezregel
trapez <- function(lower,upper,res,fun){
  
  steps <- (upper-lower)*res
  A <- 0
  
  for(i in 1:steps){
    
    x0 <- lower+(i-1)*(1/res)
    x1 <- lower+i*(1/res)
    val0 <- fun(x0)
    val1 <- fun(x1)
    
    A<- A + (x1-x0)*(0.5*val0+0.5*val1) 
  }
  return(A) 
}

# Simpsonregel (1-4-1 Variante)
simpson <- function(lower,upper,res,fun){
  
  steps <- (upper-lower)*res
  A <- 0
  
  for(i in 1:steps){
    
    x0 <- lower+(i-1)*(1/res)
    x1 <- lower+(i-0.5)*(1/res)
    x2 <- lower+(i)*(1/res)
    val0 <- fun(x0)
    val1 <- fun(x1)
    val2 <- fun(x2)
    
    A<- A + (x2-x0)*(val0*(1/6)+val1*(4/6)+val2*(1/6))
  }
  return(A) 
}

# Simpsonregel (3/8 Variante)
threeEight <- function(lower,upper,res,fun){
  
  steps <- (upper-lower)*res
  A <- 0
  
  for(i in 1:steps){
    
    x0 <- lower+(i-1)*(1/res)
    x1 <- lower+(i-2/3)*(1/res)
    x2 <- lower+(i-1/3)*(1/res)
    x3 <- lower+(i)*(1/res)
    val0 <- fun(x0)
    val1 <- fun(x1)
    val2 <- fun(x2)
    val3 <- fun(x3)
    
    A<- A + (x3-x0)*(val0*(1/8)+val1*(3/8)+val2*(3/8)+val3*(1/8))
  }
  return(A) 
}

# Booleregel
boole <- function(lower,upper,res,fun){
  
  steps <- (upper-lower)*res
  A <- 0
  
  for(i in 1:steps){
    
    x0 <- lower+(i-1)*(1/res)
    x1 <- lower+(i-3/4)*(1/res)
    x2 <- lower+(i-1/2)*(1/res)
    x3 <- lower+(i-1/4)*(1/res)
    x4 <- lower+(i)*(1/res)
    val0 <- fun(x0)
    val1 <- fun(x1)
    val2 <- fun(x2)
    val3 <- fun(x3)
    val4 <- fun(x4)
    
    A<- A + (x4-x0)*(val0*(7/90)+val1*(32/90)+val2*(12/90)+val3*(32/90)+val4*(7/90))
  }
  return(A) 
}

# 6-Punkte-Regel
sixPoints <- function(lower,upper,res,fun){
  
  steps <- (upper-lower)*res
  A <- 0
  
  for(i in 1:steps){
    
    x0 <- lower+(i-1)*(1/res)
    x1 <- lower+(i-4/5)*(1/res)
    x2 <- lower+(i-3/5)*(1/res)
    x3 <- lower+(i-2/5)*(1/res)
    x4 <- lower+(i-1/5)*(1/res)
    x5 <- lower+(i)*(1/res)
    val0 <- fun(x0)
    val1 <- fun(x1)
    val2 <- fun(x2)
    val3 <- fun(x3)
    val4 <- fun(x4)
    val5 <- fun(x5)
    A<- A + (x5-x0)*(val0*(19/288)+val1*(75/288)+val2*(50/288)+val3*(50/288)+val4*(75/288)+val5*(19/288))
  }
  return(A) 
}

# Funktion aus Übungsaufgabe 6

exercise <- function(x){
  return(sin(x))
}

solution <- 2

# Integralgrenzen & Auflösung
lower <- 0
upper <- pi
res <- 1/(0.25*pi)

# Aufruf
approxTrapez <- trapez(lower,upper,res,exercise)
approxSixPoints <- sixPoints(lower,upper,res,exercise)

# Prozentualer Fehler
(approxTrapez-solution)/solution*100
(approxSixPoints-solution)/solution*100
