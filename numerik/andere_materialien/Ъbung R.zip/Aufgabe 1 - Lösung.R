exerciseA <- function(x){
  return(0.01*x^5-0.05*x^4+0.1*x^3-0.5*x^2+x)
}

exerciseB <- function(x){
  return(exp(sin(cos(x))))
}

exerciseC <- function(x){
  return(sin(0.5*x)*x^2-cos(0.5*x^2)*x)
}

exerciseD <- function(x){
  return(sqrt(abs(log(abs(x)))))
}