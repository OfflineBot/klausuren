# Sekantenverfahren für Suche nach Nullstellen
findRoots <- function(xA,xB,epsilon,fun){
  
  valA <- fun(xA)
  valB <- fun(xB)
  
  if(abs(valB)<epsilon){
    cat(paste("Nullstelle bei ",xB," mit Wert ",valB))
    return(xB) # Abbruchbedingung
  }
  
  dx <- xB - xA # Zähler
  dy <- valB - valA # Nenner
  
  xC <- xB - dx/dy * valB # Iterationsschritt
  
  return(findRoots(xB,xC,epsilon,fun))
}

# Beispielfunktion aus Aufgabe 3 mit Nullstellen bei -2 und 5
exampleFun <- function(x){
  return(x^2-3*x-10)
}

x0 <- findRoots(0.5,1.5,0.01,exampleFun)

# d) Vermieden werden sollten Startwerte x1, x2 die den gleichen 
# Funktionswert ergeben. Für die Startwerte soll gelten: f(x1) ≠ f(x2). 