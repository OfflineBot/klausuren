# install.packages("tuneR")
library("tuneR")

wave <- readWave("Meow.wav")
data <- wave@left

resolution <- 10000
steps <- length(data)

t <- numeric(steps)
f <- numeric(steps)

for(i in 1:steps){
  t[i] <- i/resolution            # Zeitachse für Signalplot
  f[i] <- resolution*(i/steps)    # Frequenzachse für Spektrum
}

spectrum <- fft(data)

plot(f,abs(spectrum),xlim=c(0,f[steps]),ylab = "Amplitude", 
     xlab="Frequenz (Hz)", type = "l", main = "Frequenzspektrum")