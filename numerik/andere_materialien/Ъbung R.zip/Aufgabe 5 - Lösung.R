# Bibliotheken für grafische Darstellung
library(ggplot2)
library(dplyr)
library(tidyr)

# Runge Kutta 3 Verfahren (Butcher-Tablett aus Aufgabe 5)
rungeKutta3 <- function(y0,t0,fun,dt,steps){
  
  val = numeric(steps+1)
  val[1] = y0
  
  for(i in 2:(steps+1)){
    
    tC <- t0+dt*(i-1)
    
    k1 = fun(y=val[i-1],                 t=tC)
    k2 = fun(y=val[i-1]+0.5*dt*k1,       t=tC+0.5*dt)
    k3 = fun(y=val[i-1]-1*dt*k1+2*dt*k2, t=tC*dt)
    
    val[i] = val[i-1]+(dt/6)*(k1+4*k2+k3)
  }
  return(val)
}

# Eulerverfahren (RK1)
euler <- function(y0,t0,fun,dt,steps){
  
  val = numeric(steps+1)
  val[1] = y0
  
  for(i in 2:(steps+1)){
    tC <- t0+dt*(i-2)
    val[i] = val[i-1]+dt*fun(y=val[i-1],t=tC)
  }
  return(val)
}

# Hilfsfunktion für "exakte" Lösungen
exakt <- function(y0,t0,fun,dt,steps){
  
  val = numeric(steps+1)
  val[1] = y0
  
  for(i in 2:(steps+1)){
    val[i] = fun(t0+(i-1)*dt)
  }
  return(val)
}

# Hilfsfunktion für grafische Darstellung der Fehler
compare <- function(t,y1,y2,y){

  errorA <- abs(y1-y)
  errorB <- abs(y2-y)
  
  data <- data.frame(t=t,errorA=errorA,errorB=errorB)
  data <- data %>%
      pivot_longer(cols=c(errorA,errorB),names_to="Variante",values_to="Fehler")
  
  ggplot(data, aes(x = t, y = Fehler, color = Variante)) +
    geom_line(size = 1) +
    labs(title = "Error Time Series", x = "Time", y = "Error")
}

# Differenzialgleichung für die Übungsaufgabe 5
exercise <- function(y,t){
  return(y^2)
}

# Analytische Lösung für die Übungsaufgabe 5
exercise_sol <- function(t){
  return((0.25-t)^(-1))
}

# RK3 Verfahren für Beispielfunktion
y0 <- 4
t0 <- 0
dt <- 1
steps <- 5

t <- t0 + (0:steps)*dt
yK <- rungeKutta3(y0,t0,exercise,dt,steps)
yE <- euler(y0,t0,exercise,dt,steps)
y <- exakt(y0,t0,exercise_sol,dt,steps)

compare(t,yE,yK,y)