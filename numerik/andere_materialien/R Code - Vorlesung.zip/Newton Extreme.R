# Einfachere Variante
newtonExtreme <- function(x,epsilon,dx,fun){

  val0 <- fun(x)
  val1 <- fun(x+dx)
  val2 <- fun(x+2*dx)
  
  dfdx0 = (val1 - val0) / dx      # Erste Ableitung bei x
  dfdx1 = (val2 - val1) / dx      # Erste Ableitung bei x+dx
  
  d2fdx2 = (dfdx1 - dfdx0) / dx   # Zweite Ableitung
  
  # Hinreichendes Kriterium für Minimum
  if(abs(dfdx0)<epsilon & d2fdx2>epsilon){
    cat(paste("Minimum bei ",x,"\n"))
    return(x)
  }
  
  # Hinreichendes Kriterium für Maximum
  if(abs(dfdx0)<epsilon & d2fdx2<epsilon){
    cat(paste("Maximum bei ",x,"\n"))
    return(x)
  }
  
  # Wendepunkte erkennen
  if(abs(dfdx0)<epsilon){
    cat(paste("Wendepunkt bei ",x,"\n"))
    return(x)
  }
  
  newX = x - dfdx0/d2fdx2 # Simpsonsche Formel
  
  return(newtonExtreme(newX,epsilon,dx,fun))
}

# Fortgeschrittene Variante für Mehrfachaufruf
newtonExtreme2 <- function(x,x0,epsilon,dx,fun,maxIter){
  
  if(is.na(x0))x0<-x # Startwert setzen
  if(maxIter<=0)return(NaN) # Abbruchbedingung
  
  val0 <- fun(x)
  val1 <- fun(x+dx)
  val2 <- fun(x+2*dx)
  
  dfdx0 = (val1 - val0) / dx      # Erste Ableitung bei x
  dfdx1 = (val2 - val1) / dx      # Erste Ableitung bei x+dx
  
  d2fdx2 = (dfdx1 - dfdx0) / dx   # Zweite Ableitung
  
  # Hinreichendes Kriterium für Minimum
  if(abs(dfdx0)<epsilon & d2fdx2>epsilon){
    return(list(x0=x0,value=x,type="minimum"))
  }
  
  # Hinreichendes Kriterium für Maximum
  if(abs(dfdx0)<epsilon & d2fdx2<epsilon){
    return(list(x0=x0,value=x,type="maximum"))
  }
  
  # Wendepunkte erkennen
  if(abs(dfdx0)<epsilon){
    return(list(x0=x0,value=x,type="inflection"))
  }
  
  newX = x - dfdx0/d2fdx2 # Simpsonsche Formel
  
  return(newtonExtreme2(newX,x0,epsilon,dx,fun,maxIter-1))
}

# Beispielfunktion mit globalen Minima bei +/- 1 und lokalem Maximum bei 0
exampleFun <- function(x){
  return(x^4-2*x^2)
}

# Beispielfunktion mit Lokalen Extrema bei +/- Wurzel 2/3
exampleFun2 <- function(x){
  return(x^3-2*x+2)
}

# Mehrfacher Funktionsaufruf

epsilon <- 0.01   # Geforderte Genauigkeit bezüglich f(x)
dx <- 0.01        # Breite des Steigungsdreiecks
maxIter <- 100    # Maximale Anzahl an Iterationen

lower <- -5       # Untergrenze für Startwerte
upper <- 5        # Obergrenze für Startwerte
res <- 0.5        # Auflösung

xVal <- seq(lower,upper,res)
yVal <- apply(as.matrix(xVal),1,newtonExtreme2,
              x0=NA,epsilon=epsilon,dx=dx,fun=exampleFun,maxIter=maxIter)

result <- as.data.frame(do.call(rbind, yVal))