# Newton-Algorithmus für Suche nach Nullstellen
newtonRoots <- function(x,epsilon,dx,fun,maxIter){
  
  val <- fun(x)
  
  if(maxIter<=0)return(NaN) # Abbruch, keine Nullstelle gefunden
  if(abs(val)<epsilon)return(x) # Abbruch, Nullstelle gefunden
  
  dfx <- (fun(x+dx)-val)/dx # Ableitung über Steigungsdreieck
  newX = x - val/dfx # Simpsonsche Formel
  
  return(newtonRoots(newX,epsilon,dx,fun,maxIter-1))
}

# Beispielfunktion mit Nullstellen bei 0 und +/- Wurzel 2
exampleFun <- function(x){
  return(x^4-2*x^2)
}

# Beispielfunktion mit Nullstelle bei -1.7693...
exampleFun2 <- function(x){
  return(x^3-2*x+2)
}

# Mehrfacher Funktionsaufruf

epsilon <- 0.01   # Geforderte Genauigkeit bezüglich f(x)
dx <- 0.01        # Breite des Steigungsdreiecks
maxIter <- 100    # Maximale Anzahl an Iterationen

lower <- -5       # Untergrenze für Startwerte
upper <- 5        # Obergrenze für Startwerte
res <- 0.1        # Auflösung

xVal <- seq(lower,upper,res)
yVal <- apply(as.matrix(xVal),1,newtonRoots,
              epsilon=epsilon,dx=dx,fun=exampleFun,maxIter=maxIter)

# Die folgende Grafik zeigt, welche Nullstelle mit welchem Startwert
# gefunden wird. Lücken in der Grafik bedeuten Divergenz, d.h. dass
# zu einem Startwert keine Nullstelle gefunden wurde.
plot(xVal,yVal)
