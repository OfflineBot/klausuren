# Grid Search für Suche nach globalem Maximum
gs_max <- function(lower,upper,res,fun){
   
  span <- upper-lower   # Intervallbreite
  steps <- span/res     # Anzahl Auswertungen
  
  maxVal <- -Inf        # Bisher größter Funktionswert
  maxPos <- -Inf        # gefunden an dieser Stelle
  
  for(i in 0:steps){
    x <- lower + i*res  # Wert von x
    val <- fun(x)       # Wert von f(x)
    
    if(val > maxVal){   # Neues Maximum ersetzt bisheriges
      maxVal <- val
      maxPos <- x
    }
  }
  
  return(maxPos)
}

# Alternative Implementierung
gs_max2 <- function(lower,upper,res,fun){
  
  x <- seq(lower,upper,res) # Werte von x
  val <- fun(x)             # Werte von f(x)
  
  posMax <- which.max(val)
  return(x[posMax])
}

# Beispielfunktion mit Maximum bei +/- Wurzel Pi
piFun <- function(x){
  return(1-exp((x^2-pi)^2))
}

# Beispielfunktion mit Maximum bei -1
exampleFun <- function(x){
  return(-(x+1)^2+1)
}

# Beispiele für Funktionsaufruf
gs_max(-3,1,0.2,exampleFun)
gs_max(-3,3,0.00001,piFun)

gs_max2(-3,1,0.2,exampleFun)
gs_max2(-3,3,0.00001,piFun)
