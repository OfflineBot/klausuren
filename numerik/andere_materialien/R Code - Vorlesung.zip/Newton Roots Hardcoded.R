# Newton-Algorithmus für Suche nach Nullstellen
newtonRoots <- function(x,epsilon,fun,derivative){
  
  val <- fun(x)
  
  if(abs(val)<epsilon){
    cat(paste("Nullstelle bei ",x," mit Wert ",val))
    return(x) # Abbruchbedingung
  }
  
  dfx <- derivative(x) # Analytische Ableitung
  newX = x - val/dfx # Simpsonsche Formel
  
  return(newtonRoots(newX,epsilon,fun,derivative)) # Rekursive Iteration
}

# Beispielfunktion mit Nullstellen bei 0 und +/- Wurzel 2
exampleFun <- function(x){
  return(x^4-2*x^2)
}

# Ableitung der Beispielfunktion die wir analytisch berechnen müssen.
exampleDerivative <- function(x){
  return(4*x^3-4*x)
}

# Funktionsaufruf
x0 <- newtonRoots(-0.9,0.1,exampleFun,exampleDerivative)
