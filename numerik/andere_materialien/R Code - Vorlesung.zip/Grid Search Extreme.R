# Algorithmus für Suche nach Extremstellen
gs_extreme <- function(lower,upper,res,fun){
  
  x <- seq(lower,upper,res) # Werte von x
  val <- fun(x)             # Werte von f(x)
  
  minVal <- min(val)        # Wert des globales Minimum
  maxVal <- max(val)        # Wert des globales Maximum
    
  posMin <- numeric(0)      # Stellen mit Minimum
  posMax <- numeric(0)      # Stellem mit Maximum

  for(i in 2:(length(val)-1)){
    # Pattern für Minimum
    if(val[i] < val[i-1] & val[i] < val[i+1]){
      posMin[length(posMin)+1] <- x[i]       
    }
    
    # Pattern für Maximum
    if(val[i] > val[i-1] & val[i] > val[i+1]){
      posMax[length(posMax)+1] <- x[i]       
    }
  }
  
  for(i in 1:length(posMax)){
    if(fun(posMax[i])==maxVal)cat(paste("Globales Maximum bei ",posMax[i],"\n"))
    else cat(paste("Lokales Maximum bei ",posMax[i],"\n"))
  }
  
  for(i in 1:length(posMin)){
    if(fun(posMin[i])==minVal)cat(paste("Globales Minimum bei ",posMin[i],"\n"))
    else cat(paste("Lokales Minimum bei ",posMin[i],"\n"))
  }
}

# Beispielfunktion mit globalen Minima bei +/-1 und lokalem Maximum bei 0
exampleFun <- function(x){
  return(4*x^4-8*x^2)
}

t0 <- as.numeric(Sys.time()) # Unixzeit vor Funktionsaufruf
gs_extreme(-3,3,0.00001,exampleFun) # Funktionsaufruf
cat(paste("Ausführungszeit: ",as.numeric((Sys.time()-t0))*1000, " ms")) # Unixzeit danach
