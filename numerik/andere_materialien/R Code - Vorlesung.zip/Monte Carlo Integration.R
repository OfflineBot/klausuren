# Monte-Carlo Integration
MCI_Quick <- function(lower,upper,n,fun){
  
  nVal <- numeric(0)
  
  for(i in 1:n){
    nVal[i] <- fun(runif(1,lower,upper))
  }
  return(sum(nVal)/length(nVal)) 
}

# Monte-Carlo Integration mit Einzelinformation
MCI <- function(lower,upper,n,fun){
  
  nVal <- numeric(0)
  A <- numeric(0)
  
  for(i in 1:n){
    nVal[i] <- fun(runif(1,lower,upper))
    A[i]<- sum(nVal)/length(nVal)
  }
  return(A) 
}

# Integrale

exampleA <- function(x){
  return(exp(x))
}

exampleB <- function(x){
  return(1/(1+x^2))
}

exampleC <- function(x){
  return(sqrt(log(x+1)))
}

exampleD <- function(x){
  return(1+sin(2*pi*x))
}

# Lösungskonstanten
solA <- 1.71828182845904523
solB <- 0.78539816339744828
solC <- 0.59259042249756967
solD <- 1

# Integralgrenzen & Auflösung
lower <- 0
upper <- 1
n <- 50

# Aufruf mit Entwicklung prozentualer Fehler
A <- MCI(lower,upper,n,exampleA)
err <- (A-solA)/solA
plot(abs(err),type="l")

# Aufruf mit Verteilung prozentualer Fehler
A <- numeric(0)
for(i in 1:1000){
  A[i] <- MCI_Quick(lower,upper,n,exampleA)
}

err <- (A-solA)/solA
hist(err)
