# Bibliotheken für grafische Darstellung
library(ggplot2)
library(dplyr)
library(tidyr)

# Runge Kutta 4 Verfahren
rungeKutta4 <- function(y0,t0,fun,dt,steps){
  
  val = numeric(steps+1)
  val[1] = y0
  
  for(i in 2:(steps+1)){
    
    tC <- t0+dt*(i-1)
    
    k1 = fun(y=val[i-1],           t=tC)
    k2 = fun(y=val[i-1]+0.5*dt*k1, t=tC+0.5*dt)
    k3 = fun(y=val[i-1]+0.5*dt*k2, t=tC+0.5*dt)
    k4 = fun(y=val[i-1]+dt*k3,     t=tC+dt)
    
    val[i] = val[i-1]+(dt/6)*(k1+2*k2+2*k3+k4)
  }
  return(val)
}

# Mittelpunktregel (RK2)
mittelpunkt <- function(y0,t0,fun,dt,steps){
  
  val = numeric(steps+1)
  val[1] = y0
  
  for(i in 2:(steps+1)){
    
    tC <- t0+dt*(i-1)
    
    k1 = fun(y=val[i-1],           t=tC)
    k2 = fun(y=val[i-1]+0.5*dt*k1, t=tC+0.5*dt)
    
    val[i] = val[i-1]+dt*k2
  }
  return(val)
}

# Eulerverfahren (RK1)
euler <- function(y0,t0,fun,dt,steps){
  
  val = numeric(steps+1)
  val[1] = y0
  
  for(i in 2:(steps+1)){
    tC <- t0+dt*(i-1)
    val[i] = val[i-1]+dt*fun(y=val[i-1],t=tC)
  }
  return(val)
}

# Hilfsfunktion für "exakte" Lösungen
exakt <- function(y0,t0,fun,dt,steps){
  
  val = numeric(steps+1)
  val[1] = y0
  
  for(i in 2:(steps+1)){
    val[i] = fun(t0+(i-1)*dt)
  }
  return(val)
}

# Hilfsfunktion für grafische Darstellung der Fehler
compare <- function(t,y1,y2,y){

  errorA <- abs(y1-y)
  errorB <- abs(y2-y)
  
  data <- data.frame(t=t,errorA=errorA,errorB=errorB)
  data <- data %>%
      pivot_longer(cols=c(errorA,errorB),names_to="Variante",values_to="Fehler")
  
  ggplot(data, aes(x = t, y = Fehler, color = Variante)) +
    geom_line(size = 1) +
    labs(title = "Error Time Series", x = "Time", y = "Error")
}

# Differenzialgleichungen und ihre analytischen Lösungen

airQuality <- function(y,t){
  return(-0.01*y+10)
}

airQuality_sol <- function(t){
  return(1000-1000*exp(-0.01*t))
}

nonlinear <- function(y,t){
  return(2*t*exp(y))
}

nonlinear_sol <- function(t){
  return(-log(-t^2+1))
}

trigonometry <- function(y,t){
  return(sin(t)*sin(t)*y)
}

trigonometry_sol <- function(t){
  return(exp(0.5*(t-sin(t)*cos(t))))
}

# Beispiel Luftqualität
y0 <- 0
t0 <- 0
dt <- 0.1
steps <- 6000

t <- t0 + (0:steps)*dt
yK <- rungeKutta4(y0,t0,airQuality,dt,steps)
yM <- mittelpunkt(y0,t0,airQuality,dt,steps)
yE <- euler(y0,t0,airQuality,dt,steps)
y <- exakt(y0,t0,airQuality_sol,dt,steps)

compare(t,yM,yE,y)
compare(t,yM,yK,y)

# Nichtlineares Beispiel
dt <- 0.0001
steps <- 4999

t <- t0 + (0:steps)*dt
yK <- rungeKutta4(y0,t0,nonlinear,dt,steps)
yM <- mittelpunkt(y0,t0,nonlinear,dt,steps)
yE <- euler(y0,t0,nonlinear,dt,steps)
y <- exakt(y0,t0,nonlinear_sol,dt,steps)

compare(t,yM,yE,y)
compare(t,yM,yK,y)

# Trigonometrisches Beispiel
y0 <- 1
t0 <- 0
dt <- 0.1
steps <- 100

t <- t0 + (0:steps)*dt
yK <- rungeKutta4(y0,t0,trigonometry,dt,steps)
yM <- mittelpunkt(y0,t0,trigonometry,dt,steps)
yE <- euler(y0,t0,trigonometry,dt,steps)
y <- exakt(y0,t0,trigonometry_sol,dt,steps)

compare(t,yM,yE,y)
compare(t,yM,yK,y)
