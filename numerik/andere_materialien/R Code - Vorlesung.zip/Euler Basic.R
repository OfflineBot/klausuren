# Eulerverfahren für DGLs
euler <- function(y0,t0,fun,dt,steps){
  
  val = numeric(steps+1)  # Vektor für Funktionswerte y(t)
  val[1] = y0             # Durch AWP gegeben
  
  # Iteration
  for(i in 2:(steps+1)){
    tC <- t0+dt*(i-1)
    val[i] = val[i-1]+dt*fun(val[i-1],tC)
  }
  
  return(val)
}

# Differenzialgleichung aus dem Skript
airQuality <- function(y,t){
  return(-0.01*y+10)
}

# Parametrierung und Aufruf

y0 <- 0         # Werte des AWP
t0 <- 0         # Werte des AWP
dt <- 0.1       # Schrittweite
steps <- 6000   # Anzahl der Schritte

t <- t0 + (0:steps)*dt # Zeitachse
yEuler <- euler(y0,t0,airQuality,dt,steps) # Werteachse

# Liniendiagramm zur Visualisierung der numerischen Lösung
plot(t,yEuler,type="l",ylab="CO2 Belastung Raum(g)",xlab="Minuten ohne Lüften",main="Luftqualität") 
