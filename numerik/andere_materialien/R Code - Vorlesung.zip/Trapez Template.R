# Trapezregel
trapez <- function(lower,upper,res,fun){
  
}

# Beispielintegrale

exampleA <- function(x){
  return(exp(x))
}

exampleB <- function(x){
  return(1/(1+x^2))
}

exampleC <- function(x){
  return(sqrt(log(x+1)))
}

exampleD <- function(x){
  return(1+sin(2*pi*x))
}

# Lösungskonstanten
solA <- 1.71828182845904523
solB <- 0.78539816339744828
solC <- 0.59259042249756967
solD <- 1

# Integralgrenzen & Auflösung
lower <- 0
upper <- 1
res <- 20

# Aufruf
A <- trapez(lower,upper,res,exampleA)
B <- trapez(lower,upper,res,exampleB)
C <- trapez(lower,upper,res,exampleC)
D <- trapez(lower,upper,res,exampleD)

# Prozentualer Fehler
abs((A-solA)/solA*100)
abs((B-solB)/solB*100)
abs((C-solC)/solC*100)
abs((D-solD)/solD*100)