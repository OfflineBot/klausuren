# Trapezregel
trapez <- function(lower,upper,res,fun){
  
  steps <- (upper-lower)*res
  A <- 0
  
  for(i in 1:steps){
    
    x0 <- lower+(i-1)*(1/res)
    x1 <- lower+i*(1/res)
    val0 <- fun(x0)
    val1 <- fun(x1)
    
    A<- A + (x1-x0)*(0.5*val0+0.5*val1) 
  }
  return(A) 
}

# Simpsonregel (1-4-1 Variante)
simpson <- function(lower,upper,res,fun){
  
  steps <- (upper-lower)*res
  A <- 0
  
  for(i in 1:steps){
    
    x0 <- lower+(i-1)*(1/res)
    x1 <- lower+(i-0.5)*(1/res)
    x2 <- lower+(i)*(1/res)
    val0 <- fun(x0)
    val1 <- fun(x1)
    val2 <- fun(x2)
    
    A<- A + (x2-x0)*(val0*(1/6)+val1*(4/6)+val2*(1/6))
  }
  return(A) 
}

# Beispielintegrale

exampleA <- function(x){
  return(exp(x))
}

exampleB <- function(x){
  return(1/(1+x^2))
}

exampleC <- function(x){
  return(sqrt(log(x+1)))
}

exampleD <- function(x){
  return(1+sin(2*pi*x))
}

# Lösungskonstanten
solA <- 1.71828182845904523
solB <- 0.78539816339744828
solC <- 0.59259042249756967
solD <- 1

# Integralgrenzen & Auflösung
lower <- 0
upper <- 1
res <- 5

# Aufruf
D <- simpson(lower,upper,res,exampleD)

# Prozentualer Fehler
(D-solD)/solD*100