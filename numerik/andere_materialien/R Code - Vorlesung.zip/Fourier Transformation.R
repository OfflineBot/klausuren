####################### 1 - Einfaches Tonsignal #######################

duration = 1
resolution = 10000
steps = duration*resolution

yt <- numeric(0)
t <- numeric(0)
f <- numeric(0)
for(i in 1:steps){
  
  x <- i/resolution
  t[i] <- x                                     # Zeitachse für Signalplot
  f[i] <- resolution*(i/steps)                  # Frequenzachse für Spektrum
  yt[i] <- sin(200*2*pi*x)+2*(cos(50*2*pi*x))   # Die Werte des Signals
}
plot(t,yt)

# Signal in Frequenzen umwandeln
data <- fft(yt)

# Die Frequenzanteile sind im BETRAG von data gespeichert
plot(f,abs(data),xlim=c(0,300),ylab = "Amplitude", xlab="Frequenz (Hz)",
     type = "l", main = "Frequenzspektrum")

########################### 2 - Stromverbrauch ############################

# install.packages("readr")
library(readr)

# Der folgende Code wird über den Import-Assistenten erzeugt. Rechts unten im
# Dateibrowser Datei links anklicken und "Import Data Set" auswählen. Im Assistent
# muss das Spalten-rennzeichen und das Dezimalzeichen eingestellt werden.
data <- read_delim("Stromverbrauch2023.csv", delim = ";", escape_double = FALSE, trim_ws = TRUE)

duration = 24*365
resolution = 4
steps = duration*resolution

t <- numeric(0)
f <- numeric(0)
for(i in 1:steps){
  t[i] <- i/resolution            # Zeitachse für Signalplot
  f[i] <- resolution*(i/steps)    # Frequenzachse für Spektrum
}

plot(t,4*data$Netzlast,type="l") # Faktor 4 für Anpassung auf Einheit GW

# Zeitreihe "Netzlast" im Data-Frame "data" in Frequenzen umwandeln
data <- fft(data$Netzlast)

# Visualisierung mit Achsenbeschriftungen
plot(f,abs(data),xlim=c(0,f[1000]),ylim=c(0,15000),ylab = "Amplitude", 
     xlab="Frequenz (1/h)", type = "l", main = "Frequenzspektrum")