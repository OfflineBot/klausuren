###########################  Beispieldatensatz  ############################

x <- c(0,1,2,3,4,5,6,7,8)
y1 <- c(10,15,26,37,45,50,48,45,30)
y2 <- c(0,1,-2,3,-4,5,-6,7,-8)

##################### Polynomiale Interpolierung  ##########################

# install.packages("cmna")
library("cmna") 
library("ggplot2")

# Hilfsfunktion zur Auswertung von Polynomen
polynom <- function(coef,x){
  
  val <- 0
  for(i in 1:length(coef)){
    val=val+coef[i]*x^(i-1)
  }
  return(val)
}

# Koeffizienten des Polynoms
coef <- polyinterp(x,y2) 

# Grafische Veranschaulichung

lower <- -2
upper <- 10
res <- 50
steps <- (upper-lower)*res

y_val <- numeric(0)
x_val <- numeric(0)

for(i in 0:steps){
  x_val[i+1]<-lower+(1/res)*i
  y_val[i+1]<-polynom(coef,x_val[i+1])
}

data_fit <- data.frame(x=x_val,y=y_val)
data_original <-data.frame(x=x,y=y2)

ggplot(data_fit, aes(x = x, y = y)) +
  geom_line(size = 1) +
  geom_point(data = data_original, aes(x = x, y = y), color = "red", size = 3) +
  ylim(-50, 50) +
  labs(title = "Polynomiale Interpolierung", x = "x-Wert", y = "y-Wert")

################## Spline Interpolierung - spline()  #######################

data_fit <- data.frame(spline(x,y2,xmin=-2,xmax=10,n=100))
data_original <-data.frame(x=x,y=y2)

ggplot(data_fit, aes(x = x, y = y)) +
  geom_line(size = 1) +
  geom_point(data = data_original, aes(x = x, y = y), color = "red", size = 3) +
  ylim(-50, 50) +
  labs(title = "Spline Interpolierung", x = "x-Wert", y = "y-Wert")

################ Spline Interpolierung - splinefun()  #####################

fun <- splinefun(x,y2)

lower <- -2
upper <- 10
res <- 50
steps <- (upper-lower)*res

y_val <- numeric(0)
x_val <- numeric(0)

for(i in 0:steps){
  x_val[i+1]<-lower+(1/res)*i
  y_val[i+1]<-fun(x_val[i+1])
}

data_fit <- data.frame(x=x_val,y=y_val)
data_original <-data.frame(x=x,y=y2)

ggplot(data_fit, aes(x = x, y = y)) +
  geom_line(size = 1) +
  geom_point(data = data_original, aes(x = x, y = y), color = "red", size = 3) +
  ylim(-50, 50) +
  labs(title = "Spline Interpolierung", x = "x-Wert", y = "y-Wert")


