# Sekantenverfahren für Suche nach Nullstellen
findRoots <- function(xA,xB,epsilon,fun){
  
  valA <- fun(xA)
  valB <- fun(xB)

  if(abs(valB)<epsilon){
    cat(paste("Nullstelle bei ",xB," mit Wert ",valB))
    return(xB) # Abbruchbedingung
  }
  
  dx <- xB - xA # Zähler
  dy <- valB - valA # Nenner
  
  xC <- xB - dx/dy * valB # Iterationsschritt
  
  return(findRoots(xB,xC,epsilon,fun))
}

# Beispielfunktion mit Nullstellen bei 0 und +/- Wurzel 2
exampleFun <- function(x){
  return(x^4-2*x^2)
}

# Beispielfunktion mit Nullstelle bei -1.7693...
exampleFun2 <- function(x){
  return(x^3-2*x+2)
}

x0 <- findRoots(0.5,1.5,0.01,exampleFun)
